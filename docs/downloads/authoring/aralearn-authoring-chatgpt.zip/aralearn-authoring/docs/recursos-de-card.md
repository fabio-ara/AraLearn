# Packages de card

No AraLearn, um **package de card** é um módulo que representa um objeto de conhecimento ou uma forma de resposta cuja estrutura possui significado pedagógico. Ele reúne contrato, validação, renderização, acessibilidade, edição e avaliação. O kernel conhece apenas como packages ocupam um card; não conhece a estrutura interna de grafo, matriz, fórmula ou processo.

Essa separação resolve dois problemas:

- um catálogo crescente não obriga a refatorar o leitor e a persistência;
- uma representação especializada pode ser corrigida e testada sem criar exceções espalhadas pelo aplicativo.

## 1. Quando um package é justificável

Uma caixa visual não se torna um resource apenas por ter estilo próprio. O package é justificável quando texto, tabela genérica ou outro package existente perderia uma relação relevante, uma notação convencional ou uma operação cognitiva.

### Critério de decisão

Antes de criar um package, responda:

1. qual objeto ou relação precisa ser percebido;
2. qual gesto o estudante deverá executar;
3. qual convenção é usada na área acadêmica;
4. por que uma representação existente não preserva essa intenção;
5. como a forma continua legível, acessível e editável no celular;
6. quais situações tornam o package inadequado.

`matrix` é distinto de `table` porque posição algébrica, delimitadores e operações matriciais têm significado. `call-stack` é distinto de tabela quando precisa mostrar topo, ordem de quadros, ativação e retorno. Se um suposto “rastreamento de algoritmo” apenas listar linhas e valores, `table` é suficiente; a especialização só se sustenta quando o estado do algoritmo, sua transição e seus elementos ativos são materializados de modo que a grade genérica não expressa.

Representações múltiplas podem favorecer compreensão quando suas funções são coordenadas, mas aumentam carga quando apenas repetem ou decoram a mesma informação. Esse princípio é discutido no modelo DeFT de [Ainsworth (2006)](https://github.com/fabio-ara/AraLearn/blob/main/docs/referencias.md#ref-ainsworth2006deft).

## 2. Kernel e package

O kernel em `src/resources/kernel/` oferece:

- envelope e slots de card;
- resolução de `package@version`;
- validação estrutural e de composição;
- montagem do renderer;
- mediação de lacunas, digitação e respostas;
- seleção de instâncias para edição e assistência.

Cada diretório em `src/resources/packages/` oferece:

- `manifest`: identidade, finalidade, taxonomia, operações e limites;
- `authoringContract`: linguagem de alto nível que o autor preenche;
- `schema`: forma de `data`;
- `normalize` e `validate`: canonicalização e invariantes;
- `render`: saída visual;
- `accessibleText`: equivalente textual;
- `editableTargets`: textos que podem ser alterados sem expor a estrutura;
- `practiceTargets`: campos internos aptos a lacuna ou digitação;
- `evaluate`: quando o package é uma resposta;
- `hydrate`: somente quando a interação exige comportamento posterior.

O registro rejeita packages que não implementam essas obrigações. Um package de conteúdo precisa declarar `exposition`; um package de resposta precisa avaliar sua resposta. Edição textual e seleção por assistência são obrigatórias, enquanto edição manual da estrutura permanece desabilitada.

## 3. Catálogo como vocabulário controlado

O catálogo não é uma lista solta de nomes. Ele descreve packages com facetas controladas:

- domínios e objetos de conhecimento;
- operações cognitivas;
- convenções acadêmicas;
- modalidades de prática;
- tecnologias de renderização;
- adequações e contraindicações;
- acessibilidade e limitações;
- slots e compatibilidades de resposta.

Essa organização combina três necessidades. O modelo precisa recuperar candidatos por intenção; a manutenção precisa acrescentar termos sem alterar um algoritmo gigante; a curadoria precisa confrontar por que um candidato foi escolhido.

`consultarBibliotecaDeResources` expõe o protocolo `aralearn.resource-library.v1` de maneira progressiva:

1. `explore` mostra famílias e facetas;
2. `search` ranqueia candidatos;
3. `inspect` compara até oito perfis;
4. `contracts` entrega até quatro contratos exatos;
5. `validate_card` verifica estrutura e composição;
6. `audit_representation` examina adequação e legibilidade;
7. `preview_card` informa se o runtime pode abrir a composição.

Não se envia todo o catálogo nem todos os schemas ao modelo. A autoria planeja primeiro, busca depois e carrega apenas a lista curta. Assim, ampliar a biblioteca altera dados catalográficos e packages, não a interface da ferramenta.

## 4. Seleção e cobertura

O catálogo devolve um estado de cobertura:

- `canonical`: candidato específico para as facetas solicitadas;
- `versatile`: candidato geral que preserva a operação;
- `substitute`: aproximação possível com limitação declarada.

Esses termos descrevem o ajuste calculado, não proclamam que uma representação seja universal na academia. O agente deve confrontar convenções, exemplo e contraindicações depois da busca.

Um resultado `substitute` não interrompe a construção. O chat informa brevemente a aproximação usada e sua perda. Essa política permite produzir em áreas ainda não completamente cobertas e transforma a observação do usuário em insumo para expansão futura do catálogo.

## 5. Composição do card

Um card possui:

- zero ou mais instâncias `content`;
- no máximo uma instância `response`;
- zero ou mais instâncias `feedback`.

Packages complementares podem coexistir quando cada um desempenha uma função diferente, como um parágrafo que situa o fenômeno, uma fórmula que o formaliza e um gráfico que mostra o comportamento. A composição é inadequada quando duplica o estímulo ou obriga o estudante a reconciliar representações sem finalidade.

A prática acrescenta uma resposta compatível com o conteúdo. `choice`, `ordering` e `matching` são packages de resposta, não “modos visuais” que qualquer diagrama deve reimplementar. Lacuna e digitação podem atuar dentro do próprio objeto representado quando o package declara alvos apropriados.

## 6. Lacunas e digitação internas

Uma lacuna não é um marcador embutido no enunciado. Ela aponta para:

```text
targetInstanceId + targetPath
```

`targetInstanceId` identifica a instância; `targetPath` identifica o campo textual declarado por `practiceTargets`. O package de resposta materializa o controle exatamente nesse local.

### Independência entre lacunas

Cada lacuna possui índice e estado próprios. Suas alternativas pertencem apenas àquela lacuna e aparecem quando ela recebe foco. Tocar numa lacuna preenchida novamente a esvazia sem alterar as demais. Digitação segue a mesma identidade, mas usa entrada textual e normalização declarada.

Reutilizar o mesmo caminho ou chave para várias lacunas produziria seleção simultânea, portanto o kernel e os testes verificam unicidade e materialização de cada alvo. O preenchimento real também é medido no navegador: o rótulo substituído precisa caber ou provocar redimensionamento do nó, nunca ser recortado.

## 7. Edição manual e assistência contextual

O autor edita textos visíveis, não JSON estrutural. `editableTargets()` devolve rótulos com identificação compreensível e caminho interno. Campos como coordenadas, ids relacionais, tipos de nó e índices ficam disponíveis apenas como contexto de leitura.

A seleção visual pode abranger uma instância, um card ou um recorte hierárquico autorizado. A assistência por API recebe:

- objetivo e conversa curta;
- contexto didático de leitura;
- packages selecionados e seus contratos exatos;
- lista explícita de caminhos textuais graváveis;
- versão corrente para desfazer, refazer e restaurar.

Um modelo leve pode propor `edit_text` somente nos alvos autorizados. Uma recomposição estrutural exige o card inteiro e nova validação. O retorno nunca ganha autoridade apenas porque contém JSON bem-formado.

## 8. Motores de representação

O renderer escolhe tecnologia pela classe do problema:

| Necessidade | Tecnologia principal | Justificativa |
|---|---|---|
| grafos, fluxos e diagramas relacionais | [Graphviz/Viz.js](https://graphviz.org/) | cálculo automático de layout, rotas e dimensões a partir da topologia |
| gráficos estatísticos e planos com dados | [Vega/Vega-Lite](https://vega.github.io/vega-lite/docs/) | escalas, eixos, legendas e gramática declarativa de visualização |
| fórmulas, matrizes e reações | MathML | estrutura matemática nativa e dimensionamento tipográfico dos delimitadores |
| texto, código e tabelas | HTML semântico | seleção, reflow, acessibilidade e edição textual nativos |

O objetivo não é eliminar CSS, mas evitar que geometria acadêmica dependa de coordenadas autorais ou medições artesanais. Motores externos também têm limites: Graphviz não decide o valor pedagógico de um grafo, Vega não escolhe a escala cientificamente correta e MathML não valida uma equação.

## 9. Regras de representação acadêmica

Um contrato de alto nível deve usar conceitos da área. Exemplos:

- `graph`: vértices, arestas, direção, peso e agrupamentos, sem coordenadas;
- `relation-map`: domínio, contradomínio e pares ordenados, sem duplicar elementos;
- `matrix`: entradas, linhas, colunas e tipo de delimitador;
- `flow`: eventos, processos, decisões, ramos e junções;
- `chart`: variáveis, unidades, séries, incerteza, escala e nota metodológica;
- `interlinear-gloss`: forma, segmentação morfológica, glosas, tradução e abreviações;
- `reaction`: espécies, coeficientes, estados, cargas, condições e seta.

O contrato não pede SVG, LaTeX livre, uma tabela improvisada ou frases concatenadas. Isso reduz erro do modelo e permite que o renderer preserve convenções. Quando duas áreas usam diagramas superficialmente parecidos com semânticas distintas, packages separados são preferíveis a um contrato genérico repleto de exceções.

## 10. Leitura sem gramática adicional

O estudante não deve aprender uma legenda inventada pelo AraLearn para só então compreender o objeto. O package segue a notação reconhecida na área e o card introduz termos ou convenções que façam parte do próprio conteúdo. Uma breve instrução de leitura é apropriada quando a disciplina realmente ensina aquela representação; vocabulário de implementação ou instruções óbvias de rolagem não são conteúdo didático.

Teoria e prática admitem densidades diferentes. Um card de teoria apresenta uma transformação conceitual delimitada, sem condensar vários pressupostos. Um card de prática pode conter contexto residente mais rico porque o estudante precisa operar sobre ele; ainda assim, rótulos e relações devem permanecer legíveis.

## 11. Mobile, orientação e escalabilidade

O runtime não força todo diagrama a caber na largura do celular. A orientação decorre da estrutura:

- progressões e hierarquias longas tendem à vertical;
- comparação entre duas colunas pode exigir horizontal;
- grafos densos preservam tamanho natural e usam navegação interna.

Diagramas extensos ficam num frame com altura limitada. Dentro do frame, o gesto move o diagrama; fora dele, move o card. Barras de rolagem permanecem acessíveis sem exigir alcançar o fim de uma figura muito alta. Rótulos completos dimensionam nós antes do layout, inclusive depois do preenchimento de lacuna.

Escalabilidade significa que exemplos complexos continuam corretos, não que toda figura seja comprimida. A galeria inclui larguras móveis, temas e exemplos não triviais para expor cruzamentos, overflow, legendas, múltiplas lacunas e textos longos.

## 12. Acessibilidade

Todo package fornece `accessibleText()` e estrutura navegável quando há controles. Cor não pode ser o único código. Foco, seleção, resposta e erro precisam de contraste e forma. Alvos de toque seguem os critérios adotados pelo sistema visual.

Um equivalente textual não torna automaticamente um diagrama compreensível a todas as pessoas; ele oferece acesso ao conteúdo e base para tecnologia assistiva. Packages complexos precisam de ordem de leitura, nomes de relações e feedback contextualizados.

## 13. Validação e auditoria

`validate_card` verifica:

- envelope e slots;
- `package@version` instalado;
- schema e semântica de `data`;
- ids e caminhos de prática;
- compatibilidades entre conteúdo e resposta.

`audit_representation` acrescenta:

- `semantic_fit`: a forma preserva a intenção;
- `response_affordance`: a interação exercita o gesto planejado;
- `feedback_legibility`: o retorno pode ser relacionado à resposta.

O renderer real e os testes de navegador verificam geometria e comportamento. Nenhuma dessas etapas isolada comprova correção científica ou efetividade pedagógica com estudantes. O conjunto fornece evidência técnica; avaliação acadêmica e empírica permanece necessária.

## 14. Adicionar ou revisar um package

1. registre a justificativa pedagógica e as alternativas recusadas;
2. escolha a convenção e a tecnologia adequadas;
3. defina manifest, taxonomia, contrato e exemplo complexo;
4. implemente normalização, validação, renderer e acessibilidade;
5. declare edição e alvos de prática sem expor estrutura;
6. teste exposição, lacunas independentes, digitação e respostas compatíveis;
7. teste claro/escuro, 360/390/412 px, textos longos e dados complexos;
8. regenere catálogo e packages de autoria;
9. execute auditoria de resíduos para impedir renderer ou alias antigo;
10. atualize documentação e evidência de conformidade.

Adicionar um package não muda o kernel. Alterar o envelope, os slots ou a semântica comum é mudança de kernel e exige revisão mais ampla.
