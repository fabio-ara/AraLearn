# Estados e concorrência

O fluxo v4 não possui estado global de execução. Há três dimensões explícitas.

## Estado atual do workspace

`revision` começa em 1 e cresce em cada mutação. A resposta também informa o
estado corrente necessário para continuar. Toda escrita exige
`expectedRevision`.

O backend conserva uma linha atual por parte da árvore e um feed compacto,
limitado e não restaurável. Cada evento recente registra:

- revisão;
- operação;
- contagens e alvo resumido;
- data e responsável.

Não há snapshot do documento a cada mutação, árvore histórica nem comando de
restauração. `revision` é um contador de concorrência, não uma cópia do curso.

## Estado da microssequência

- `planned`: estrutura reservada, ainda sem conteúdo executável;
- `generated`: conteúdo produzido e ainda não revisto;
- `needs_review`: conteúdo marcado para revisão;
- `ready`: conteúdo aceito para publicação completa.

Esses estados pertencem ao documento e podem coexistir. Eles não bloqueiam
edições em outras partes.

`revision` nunca representa aprovação. Por padrão procedimental, uma construção
nova fica `generated` ou `needs_review`; `ready` registra aceitação explícita do
conteúdo corrente ou uma ordem inequívoca de avanço. A pessoa pode dispensar
auditoria ou reauditoria e ainda mandar marcar a unidade como pronta. Essa
escolha é registrada no feedback da conversa, sem novo estado, token ou trava
no banco.

Uma alteração semântica em conteúdo já `ready` devolve somente as
microssequências afetadas a `needs_review`. Isso inclui corrigir, mover ou
excluir card; copiar ou mover uma subárvore; juntar ou separar
microssequências; e mudar objetivo, guia, tópicos ou relações didáticas. Em uma
movimentação de card, origem e destino são afetados. Uma cópia preserva a
origem e invalida a cópia. Renomear sem mudar conteúdo preserva `ready`.

Sem ordem explícita, a preferência editorial é conferir o conteúdo antes de
marcar `ready`. Quando a pessoa já tiver aceitado o conteúdo corrente ou mandado
avançar, `ready` pode acompanhar a atualização de metadados ou a gravação do
conjunto integral. A validação confirma estrutura; não comprova qualidade
pedagógica.

## Estado de conclusão publicado

- `partial`: revisão privada testável com ao menos uma parte ainda não pronta;
- `complete`: todas as microssequências estão `ready`.

O catálogo não recebe `partial`. Uma publicação parcial pode ser atualizada a
partir do workspace corrente. A publicação materializa um JSON canônico; ela
não transforma as mutações anteriores em versões recuperáveis.

## Erros

- `stale_workspace_revision`: a base mudou; releia;
- `invalid_workspace_document`: a mutação produziria contrato v4 inválido;
- `workspace_entity_not_found`: id ausente;
- `workspace_entity_ambiguous`: id repetido no mesmo tipo; use identidade
  inequívoca;
- `course_incomplete`: foi solicitada conclusão completa com unidades
  pendentes; `incomplete` agrupa em cada `entityPath` todos os `reasons`;
- `workspace_position_change_forbidden`: um reparo tentou mudar a posição do
  card; use reorganização para mover e preserve a posição no objeto corrigido;
- `workspace_source_unauthorized`: um `card.sources` novo não foi declarado
  como `[source:id]` no contexto corrente; confirme a fonte, atualize o `brief`
  e repita o menor lote;
- `idempotency_key_reused`: o mesmo `requestId` recebeu outra intenção.

Na Action, `error.issues` expõe os caminhos rejeitados e o resource do card
quando identificável. `error.recovery` distingue correção com novo
`requestId`, releitura por conflito, divisão de payload, repetição idêntica,
reconexão e falha não repetível. Uma rejeição recuperável exige correção e nova
tentativa antes de responder ao autor. Se o mesmo erro persistir, apresente
`code`, caminho e mensagem, não a expressão genérica “violação estrutural”.

Nenhum erro técnico transforma o workspace em estado bloqueado nem invalida as
partes já salvas.
